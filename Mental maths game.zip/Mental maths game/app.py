from flask import Flask, render_template, jsonify
import random

app = Flask(__name__)

GRADE_SETTINGS = {
    1: {"ops": ["+"], "range": [1, 10]},
    2: {"ops": ["+", "-"], "range": [1, 20]},
    3: {"ops": ["+", "-", "*"], "range": [1, 30]},
    4: {"ops": ["*", "/"], "range": [1, 50]},
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get-settings/<int:grade>")
def get_settings(grade):
    return jsonify(GRADE_SETTINGS.get(grade, {
        "ops": ["+", "-", "*", "/"],
        "range": [1, 100]
    }))
def game():
    return render_template('index.html')

@app.route("/play")
def play():
    return render_template("play_game.html")

@app.route("/get-question")
def get_question():
    from flask import request
    grade = int(request.args.get("grade", 1))
    settings = GRADE_SETTINGS.get(grade, {"ops":["+", "-", "*", "/"], "range":[1, 100]})
    ops = settings["ops"]
    r_min, r_max = settings["range"]

    import random
    a = random.randint(r_min, r_max)
    b = random.randint(r_min, r_max)

    op = random.choice(ops)

    if op == "/":
        b = random.randint(1, r_max)
        a = b * random.randint(1, r_max)
        answer = a // b
    elif op == "*":
        answer = a * b
    elif op == "+":
        answer = a + b
    elif op == "-":
        answer = a - b

    question = f"{a} {op} {b}"
    return jsonify({"question": question, "answer": answer})


if __name__ == "__main__":
    app.run(debug=True)
