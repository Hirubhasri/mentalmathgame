let selectedGrade = null;

async function selectGrade(card) {
    document.querySelectorAll('.grade-card')
        .forEach(c => c.classList.remove('active'));

    card.classList.add('active');
    selectedGrade = card.dataset.grade;

    const res = await fetch(`/get-settings/${selectedGrade}`);
    const data = await res.json();

    document.getElementById("settings").innerHTML = `
        <p><b>Grade ${selectedGrade}</b></p>
        <p>Operations: ${data.ops.join(", ")}</p>
        <p>Range: ${data.range[0]} - ${data.range[1]}</p>
    `;
}

function startGame() {
    if (!selectedGrade) {
        alert("Please select a grade first");
        return;
    }
}

