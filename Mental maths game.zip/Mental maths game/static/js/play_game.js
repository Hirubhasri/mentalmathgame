let audioUnlocked = false;

function unlockAudio() {
  if (audioUnlocked) return;
  Object.values(sounds).forEach(sound => {
    sound.play().then(() => {
      sound.pause();
      sound.currentTime = 0;
    }).catch(()=>{});
  });
  audioUnlocked = true;
}


let totalTime = 120, questionTime=10;
let totalTimer=null, questionTimer=null;
let currentAnswer=null, grade=localStorage.getItem("selectedGrade");
let correctCount=0, wrongCount=0, skippedCount=0;

// Sounds
const sounds={
  correct:new Audio("/static/sounds/correct.wav"),
  wrong:new Audio("/static/sounds/wrong.wav"),
  timeout:new Audio("/static/sounds/timeout.wav"),
  celebrate:new Audio("/static/sounds/celebrate.wav"),
  sad:new Audio("/static/sounds/sad.wav")
};
function playSound(type){ if(sounds[type]){sounds[type].currentTime=0;sounds[type].play();}}

// TOTAL TIMER
function startTotalTimer(){
  const timeText=document.getElementById("timeText");
  const totalBar=document.getElementById("totalBar");
  totalBar.style.width="100%";
  totalTimer=setInterval(()=>{
    totalTime--;
    let m=Math.floor(totalTime/60), s=totalTime%60;
    timeText.textContent=`${m}:${s.toString().padStart(2,"0")}`;
    totalBar.style.width=`${(totalTime/120)*100}%`;
    if(totalTime<=30) timeText.classList.add("time-warning");
    if(totalTime<=0){
      clearInterval(totalTimer);
      clearInterval(questionTimer);
      showFinalScreen();
    }
  },1000);
}

// QUESTION TIMER
function startQuestionTimer(){
  clearInterval(questionTimer);
  let timeLeft=questionTime;
  const qBar=document.getElementById("qBar");
  qBar.style.width="100%"; qBar.classList.remove("q-warning");
  questionTimer=setInterval(()=>{
    timeLeft--;
    qBar.style.width=`${(timeLeft/questionTime)*100}%`;
    if(timeLeft<=3) qBar.classList.add("q-warning");
    if(timeLeft<=0){
      clearInterval(questionTimer);
      skippedCount++;
      updateStats();
      loadQuestion();
    }
  },1000);
}

// LOAD QUESTION
async function loadQuestion(){
  startQuestionTimer();
  const questionEl=document.getElementById("question");
  const input=document.getElementById("answer");
  questionEl.textContent="Loading...";
  try{
    const res=await fetch(`/get-question?grade=${grade}`);
    const data=await res.json();
    currentAnswer=data.answer;
    questionEl.textContent=data.question;
    input.value=""; input.focus();
  }catch(err){ console.error(err); questionEl.textContent="Error loading question!"; }
}

// CHECK ANSWER
document.addEventListener("keydown",(e)=>{
  if(e.key==="Enter"){
    unlockAudio();
    const input=document.getElementById("answer");
    const userAns=parseInt(input.value);
    if(isNaN(userAns)) return;
    if(userAns===currentAnswer){
      correctCount++; playSound("correct"); updateStats(); clearInterval(questionTimer); loadQuestion();
    }else{
      wrongCount++; playSound("wrong"); updateStats();
    }
  }
});

// UPDATE STATS
function updateStats(){
  const c=document.getElementById("correct");
  const w=document.getElementById("wrong");
  const s=document.getElementById("skipped");
  if(c) c.textContent=correctCount;
  if(w) w.textContent=wrongCount;
  if(s) s.textContent=skippedCount;
}

// FINAL SCREEN + CONFETTI + PLAY AGAIN
function showFinalScreen(){
  document.querySelector(".card").style.display="none";
  document.querySelector(".top-bar").style.display="none";
  document.querySelector(".stats").style.display="none";

  const fs = document.getElementById("finalScreen");
  fs.innerHTML = ""; // clear old content
  fs.classList.remove("hidden");

  let message = "";
  let showConfetti = false;

  if(correctCount === 0){
    message = "Oops! Score 0 😢";
    playSound("timeout"); // your sound function
  }
  else if(correctCount <= 5){
    message = `Good! Keep trying! 🎯 Score: ${correctCount}`;
    playSound("success");
    showConfetti = false; // <=5 no confetti as you requested
  }
  else{
    message = `Excellent! 🎉 You scored ${correctCount}!`;
    playSound("celebrate");
    showConfetti = true;
  }

  // MESSAGE
  const msgEl = document.createElement("h1");
  msgEl.textContent = message;
  fs.appendChild(msgEl);

  // SCORE
  const scoreEl = document.createElement("h2");
  scoreEl.textContent = `Score: ${correctCount}`;
  fs.appendChild(scoreEl);

  // PLAY AGAIN BUTTON
  const btn = document.createElement("button");
  btn.textContent = "Play Again";
  btn.classList.add("play-again");
  btn.onclick = () => location.reload();
  fs.appendChild(btn);

  // CONFETTI
  if(showConfetti){
    for(let i=0; i<70; i++){
      createConfetti(fs);
    }
  }
}


// ---------------- CONFETTI ----------------
function createConfetti(parent){
  const conf = document.createElement("div");
  conf.classList.add("confetti-piece");
  conf.style.left = Math.random()*100 + "%";
  conf.style.backgroundColor = `hsl(${Math.random()*360},100%,50%)`;
  conf.style.animationDuration = (Math.random()*2 + 2) + "s"; // 2-4s
  conf.style.position = "absolute";
  conf.style.width = "10px";
  conf.style.height = "10px";
  conf.style.top = "0";

  parent.appendChild(conf);

  setTimeout(()=>{ conf.remove(); }, 4000);
}


// START GAME
document.addEventListener("DOMContentLoaded",()=>{
  if(!grade){ alert("Select grade first!"); return; }
  startTotalTimer(); loadQuestion();
});



